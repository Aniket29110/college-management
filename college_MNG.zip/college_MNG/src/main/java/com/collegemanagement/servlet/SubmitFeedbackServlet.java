package com.collegemanagement.servlet;

import com.collegemanagement.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/submit-feedback")
public class SubmitFeedbackServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public SubmitFeedbackServlet() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String studentId = (String) session.getAttribute("user");
        String message = request.getParameter("message");

        if (message == null || message.trim().isEmpty()) {
            request.setAttribute("error", "Feedback message cannot be empty.");
            response.sendRedirect("dashboard.jsp?error=Feedback%20message%20cannot%20be%20empty.");
            return;
        }

        String sql = "INSERT INTO feedback (student_id, message) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, studentId);
            pstmt.setString(2, message.trim());
            pstmt.executeUpdate();

            response.sendRedirect("dashboard.jsp?msg=Feedback%20submitted%20successfully.");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("dashboard.jsp?error=Database%20error%20submitting%20feedback.");
        }
    }
}
