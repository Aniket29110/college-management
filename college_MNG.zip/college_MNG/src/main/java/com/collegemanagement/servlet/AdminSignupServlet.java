package com.collegemanagement.servlet;

import com.collegemanagement.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/dsignup")
public class AdminSignupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public AdminSignupServlet() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.sendRedirect("dsignup.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String adminName = request.getParameter("c");
        String userId = request.getParameter("a");
        String password = request.getParameter("b");

        if (adminName == null || adminName.trim().isEmpty() ||
            userId == null || userId.trim().isEmpty() ||
            password == null || password.trim().isEmpty()) {
            request.setAttribute("error", "All fields are required for admin registration.");
            request.getRequestDispatcher("dsignup.jsp").forward(request, response);
            return;
        }

        String sql = "INSERT INTO adminsignup (name, uid, password) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, adminName.trim());
            pstmt.setString(2, userId.trim());
            pstmt.setString(3, password.trim());

            pstmt.executeUpdate();

            request.setAttribute("msg", "Admin registration successful! You can now log in.");
            request.getRequestDispatcher("deen.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Registration failed. Admin ID may already exist or DB error occurred.");
            request.getRequestDispatcher("dsignup.jsp").forward(request, response);
        }
    }
}
