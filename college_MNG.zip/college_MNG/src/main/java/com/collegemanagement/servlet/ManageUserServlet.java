package com.collegemanagement.servlet;

import com.collegemanagement.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/manage-users")
public class ManageUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ManageUserServlet() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || !"Administrator".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String targetRole = request.getParameter("role");
        String name = request.getParameter("name");
        String uid = request.getParameter("uid");
        String password = request.getParameter("password");

        if (targetRole == null || name == null || uid == null || password == null ||
            targetRole.trim().isEmpty() || name.trim().isEmpty() || uid.trim().isEmpty() || password.trim().isEmpty()) {
            response.sendRedirect("dashboard.jsp?error=All%20fields%20are%20required%20for%20user%20registration.");
            return;
        }

        String table = "studentsignup";
        if ("Faculty".equalsIgnoreCase(targetRole.trim())) {
            table = "facultysignup";
        }

        String sql = "INSERT INTO " + table + " (name, uid, password) VALUES (?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE name = ?, password = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, name.trim());
            pstmt.setString(2, uid.trim());
            pstmt.setString(3, password.trim());
            pstmt.setString(4, name.trim());
            pstmt.setString(5, password.trim());
            pstmt.executeUpdate();

            response.sendRedirect("dashboard.jsp?msg=User%20account%20created/updated%20successfully.");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("dashboard.jsp?error=Database%20error%20registering%20user.");
        }
    }
}
