package com.collegemanagement.servlet;

import com.collegemanagement.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/signup1")
public class StudentSignupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public StudentSignupServlet() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.sendRedirect("ssignup.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String studentName = request.getParameter("c");
        String userId = request.getParameter("a");
        String password = request.getParameter("b");

        if (studentName == null || studentName.trim().isEmpty() ||
            userId == null || userId.trim().isEmpty() ||
            password == null || password.trim().isEmpty()) {
            request.setAttribute("error", "All fields are required for registration.");
            request.getRequestDispatcher("ssignup.jsp").forward(request, response);
            return;
        }

        String sql = "INSERT INTO studentsignup (name, uid, password) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, studentName.trim());
            pstmt.setString(2, userId.trim());
            pstmt.setString(3, password.trim());

            pstmt.executeUpdate();

            request.setAttribute("msg", "Registration successful! You can now log in.");
            request.getRequestDispatcher("student.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Registration failed. User ID may already exist or DB error occurred.");
            request.getRequestDispatcher("ssignup.jsp").forward(request, response);
        }
    }
}
