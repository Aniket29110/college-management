package com.collegemanagement.servlet;

import com.collegemanagement.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/manage-courses")
public class ManageCourseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ManageCourseServlet() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || !"Administrator".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String courseCode = request.getParameter("course_code");
        String courseName = request.getParameter("course_name");
        String creditsStr = request.getParameter("credits");
        String facultyId = request.getParameter("faculty_id");

        if (courseCode == null || courseName == null || creditsStr == null || facultyId == null ||
            courseCode.trim().isEmpty() || courseName.trim().isEmpty() || creditsStr.trim().isEmpty() || facultyId.trim().isEmpty()) {
            response.sendRedirect("dashboard.jsp?error=All%20fields%20are%20required%20for%20course%20creation.");
            return;
        }

        try {
            int credits = Integer.parseInt(creditsStr.trim());
            
            String sql = "INSERT INTO courses (course_code, course_name, credits, faculty_id) VALUES (?, ?, ?, ?) " +
                         "ON DUPLICATE KEY UPDATE course_name = ?, credits = ?, faculty_id = ?";
            
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, courseCode.trim().toUpperCase());
                pstmt.setString(2, courseName.trim());
                pstmt.setInt(3, credits);
                pstmt.setString(4, facultyId.trim());
                pstmt.setString(5, courseName.trim());
                pstmt.setInt(6, credits);
                pstmt.setString(7, facultyId.trim());
                pstmt.executeUpdate();

                response.sendRedirect("dashboard.jsp?msg=Course%20created/updated%20successfully.");
            }
        } catch (NumberFormatException e) {
            response.sendRedirect("dashboard.jsp?error=Credits%20must%20be%20a%20valid%20integer.");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("dashboard.jsp?error=Database%20error%20saving%20course.");
        }
    }
}
