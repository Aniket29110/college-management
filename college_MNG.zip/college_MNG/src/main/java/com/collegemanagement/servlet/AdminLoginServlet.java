package com.collegemanagement.servlet;

import com.collegemanagement.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/dlogin")
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public AdminLoginServlet() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.sendRedirect("deen.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userId = request.getParameter("a");
        String password = request.getParameter("b");

        if (userId == null || userId.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            request.setAttribute("error", "Admin ID and Password are required.");
            request.getRequestDispatcher("deen.jsp").forward(request, response);
            return;
        }

        String sql = "SELECT * FROM adminsignup WHERE uid = ? AND password = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, userId.trim());
            pstmt.setString(2, password.trim());

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String adminName = rs.getString("name");
                    HttpSession session = request.getSession();
                    session.setAttribute("user", userId);
                    session.setAttribute("userName", adminName != null ? adminName : userId);
                    session.setAttribute("role", "Administrator");
                    response.sendRedirect("dashboard.jsp");
                } else {
                    request.setAttribute("error", "Invalid Admin ID or Password.");
                    request.getRequestDispatcher("deen.jsp").forward(request, response);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Database connection error. Please try again later.");
            request.getRequestDispatcher("deen.jsp").forward(request, response);
        }
    }
}
