package com.collegemanagement.servlet;

import com.collegemanagement.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/manage-grades")
public class ManageGradeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ManageGradeServlet() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || !"Faculty".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String courseCode = request.getParameter("course_code");
        String studentId = request.getParameter("student_id");
        String marksStr = request.getParameter("marks");
        String grade = request.getParameter("grade");

        if (courseCode == null || studentId == null || marksStr == null || grade == null ||
            courseCode.trim().isEmpty() || studentId.trim().isEmpty() || marksStr.trim().isEmpty() || grade.trim().isEmpty()) {
            response.sendRedirect("dashboard.jsp?error=All%20fields%20are%20required%20for%20grading.");
            return;
        }

        try {
            int marks = Integer.parseInt(marksStr.trim());
            if (marks < 0 || marks > 100) {
                response.sendRedirect("dashboard.jsp?error=Marks%20must%20be%20between%200%20and%20100.");
                return;
            }

            // Insert or Update (upsert)
            String sql = "INSERT INTO grades (student_id, course_code, marks, grade) VALUES (?, ?, ?, ?) " +
                         "ON DUPLICATE KEY UPDATE marks = ?, grade = ?";
            
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, studentId.trim());
                pstmt.setString(2, courseCode.trim());
                pstmt.setInt(3, marks);
                pstmt.setString(4, grade.trim());
                pstmt.setInt(5, marks);
                pstmt.setString(6, grade.trim());
                pstmt.executeUpdate();

                response.sendRedirect("dashboard.jsp?msg=Grade%20submitted%20successfully.");
            }
        } catch (NumberFormatException e) {
            response.sendRedirect("dashboard.jsp?error=Marks%20must%20be%20a%20valid%20integer.");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("dashboard.jsp?error=Database%20error%20recording%20grade.");
        }
    }
}
