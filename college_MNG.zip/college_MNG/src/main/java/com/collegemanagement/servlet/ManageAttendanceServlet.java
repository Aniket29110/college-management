package com.collegemanagement.servlet;

import com.collegemanagement.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Date;

@WebServlet("/manage-attendance")
public class ManageAttendanceServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ManageAttendanceServlet() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || !"Faculty".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String courseCode = request.getParameter("course_code");
        String studentId = request.getParameter("student_id");
        String dateStr = request.getParameter("date");
        String status = request.getParameter("status");

        if (courseCode == null || studentId == null || dateStr == null || status == null ||
            courseCode.trim().isEmpty() || studentId.trim().isEmpty() || dateStr.trim().isEmpty() || status.trim().isEmpty()) {
            response.sendRedirect("dashboard.jsp?error=All%20fields%20are%20required%20for%20attendance.");
            return;
        }

        try {
            Date date = Date.valueOf(dateStr.trim());
            
            // Insert or Update (upsert)
            String sql = "INSERT INTO attendance (student_id, course_code, date, status) VALUES (?, ?, ?, ?) " +
                         "ON DUPLICATE KEY UPDATE status = ?";
            
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, studentId.trim());
                pstmt.setString(2, courseCode.trim());
                pstmt.setDate(3, date);
                pstmt.setString(4, status.trim());
                pstmt.setString(5, status.trim());
                pstmt.executeUpdate();

                response.sendRedirect("dashboard.jsp?msg=Attendance%20recorded%20successfully.");
            }
        } catch (IllegalArgumentException e) {
            response.sendRedirect("dashboard.jsp?error=Invalid%20date%20format.%20Use%20YYYY-MM-DD.");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("dashboard.jsp?error=Database%20error%20recording%20attendance.");
        }
    }
}
