package com.collegemanagement.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String DEFAULT_URL = "jdbc:mysql://bsnmvoikuzs0xfd1kcft-mysql.services.clever-cloud.com:21363/bsnmvoikuzs0xfd1kcft?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DEFAULT_USER = "uhzagmydfyjymv0s";
    private static final String DEFAULT_PASS = "aALf9UggU87rVxgcH8Z";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static boolean initialized = false;

    public static Connection getConnection() throws SQLException {
        String url = System.getenv("DB_URL");
        if (url == null || url.trim().isEmpty()) {
            url = DEFAULT_URL;
        }

        String user = System.getenv("DB_USER");
        if (user == null || user.trim().isEmpty()) {
            user = DEFAULT_USER;
        }

        String pass = System.getenv("DB_PASS");
        if (pass == null || pass.trim().isEmpty()) {
            pass = DEFAULT_PASS;
        }

        Connection conn = DriverManager.getConnection(url, user, pass);
        if (!initialized) {
            initializeDatabase(conn);
        }
        return conn;
    }

    private static synchronized void initializeDatabase(Connection conn) {
        if (initialized) return;
        try (java.sql.Statement stmt = conn.createStatement()) {
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS studentsignup (name VARCHAR(255), uid VARCHAR(255) PRIMARY KEY, password VARCHAR(255))");
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS facultysignup (name VARCHAR(255), uid VARCHAR(255) PRIMARY KEY, password VARCHAR(255))");
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS adminsignup (name VARCHAR(255), uid VARCHAR(255) PRIMARY KEY, password VARCHAR(255))");
            
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS courses (" +
                    "course_code VARCHAR(20) PRIMARY KEY, " +
                    "course_name VARCHAR(100), " +
                    "credits INT, " +
                    "faculty_id VARCHAR(50))");

            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS grades (" +
                    "student_id VARCHAR(50), " +
                    "course_code VARCHAR(20), " +
                    "marks INT, " +
                    "grade VARCHAR(10), " +
                    "PRIMARY KEY (student_id, course_code))");

            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS attendance (" +
                    "student_id VARCHAR(50), " +
                    "course_code VARCHAR(20), " +
                    "date DATE, " +
                    "status VARCHAR(20), " +
                    "PRIMARY KEY (student_id, course_code, date))");

            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS feedback (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "student_id VARCHAR(50), " +
                    "message TEXT, " +
                    "submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

            try (java.sql.ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM adminsignup")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    stmt.executeUpdate("INSERT INTO adminsignup VALUES ('Dean Admin', 'admin', '1234')");
                }
            }

            try (java.sql.ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM studentsignup")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    stmt.executeUpdate("INSERT INTO studentsignup VALUES ('John Doe', 'student', '1234')");
                }
            }

            try (java.sql.ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM facultysignup")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    stmt.executeUpdate("INSERT INTO facultysignup VALUES ('Dr. Jane Smith', 'faculty', '1234')");
                }
            }

            try (java.sql.ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM courses")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    stmt.executeUpdate("INSERT INTO courses VALUES ('CS101', 'Introduction to Computer Science', 4, 'faculty')");
                    stmt.executeUpdate("INSERT INTO courses VALUES ('MA101', 'Calculus I', 3, 'faculty')");
                    stmt.executeUpdate("INSERT INTO courses VALUES ('PH101', 'Physics I', 4, 'faculty')");
                }
            }

            try (java.sql.ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM grades")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    stmt.executeUpdate("INSERT INTO grades VALUES ('student', 'CS101', 85, 'A')");
                    stmt.executeUpdate("INSERT INTO grades VALUES ('student', 'MA101', 78, 'B')");
                }
            }

            try (java.sql.ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM attendance")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    stmt.executeUpdate("INSERT INTO attendance VALUES ('student', 'CS101', '2026-07-27', 'Present')");
                    stmt.executeUpdate("INSERT INTO attendance VALUES ('student', 'CS101', '2026-07-28', 'Present')");
                    stmt.executeUpdate("INSERT INTO attendance VALUES ('student', 'CS101', '2026-07-29', 'Absent')");
                    stmt.executeUpdate("INSERT INTO attendance VALUES ('student', 'MA101', '2026-07-28', 'Present')");
                }
            }

            initialized = true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
