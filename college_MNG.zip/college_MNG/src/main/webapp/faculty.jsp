<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Faculty Login - BBDU Lucknow</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url('bbd_faculty.png');">
    <div class="glass-container">
        <div class="bbd-badge">
            👨‍🏫 Faculty Portal
        </div>
        <h1>Faculty Login</h1>
        <h2>Babu Banarasi Das University</h2>
        
        <% if (request.getAttribute("error") != null) { %>
            <div class="alert alert-error">⚠️ <%= request.getAttribute("error") %></div>
        <% } %>
        <% if (request.getAttribute("msg") != null) { %>
            <div class="alert alert-success">✅ <%= request.getAttribute("msg") %></div>
        <% } %>
        
        <form action="flogin" method="post">
            <div class="form-group">
                <label for="username">Faculty Employee ID</label>
                <input type="text" id="username" name="a" required placeholder="Enter Faculty ID"/>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="b" required placeholder="Enter Password"/>
            </div>
            
            <div class="btn-group">
                <input type="submit" class="btn btn-primary" value="Sign In">
                <input type="reset" class="btn btn-secondary" value="Cancel">
            </div>
        </form>
        
        <a href="fsignup.jsp" class="footer-link">New Faculty Member? Register Here</a>
        <br>
        <a href="login.jsp" class="footer-link">← Back to Portal Selection</a>
    </div>

    <footer>
        © <%= java.time.Year.now() %> Babu Banarasi Das University, Lucknow. All Rights Reserved.
    </footer>
</body>
</html>