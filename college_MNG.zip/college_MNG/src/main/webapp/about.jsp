<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>About Us - Babu Banarasi Das University, Lucknow</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url('bbd_campus.png');">
    <div class="glass-container" style="max-width: 680px;">
        <div class="bbd-badge">
            🏛️ About BBDU Lucknow
        </div>
        <h1>About Our Institution</h1>
        <h2>Babu Banarasi Das University (BBDU), Lucknow</h2>
        
        <div style="margin: 20px 0; color: var(--text-muted); line-height: 1.7; text-align: justify; font-size: 0.94rem;">
            <p style="margin-bottom: 12px;">
                Established in honor of <strong>Late Babu Banarasi Das Ji</strong> (Former Chief Minister of Uttar Pradesh), BBDU Lucknow is a premier state private university set on a sprawling 100+ acre campus along Faizabad Road, Lucknow.
            </p>
            <p style="margin-bottom: 12px;">
                BBDU offers multi-disciplinary programs in <strong>Engineering (B.Tech/M.Tech), Computer Applications (BCA/MCA), Management (BBA/MBA), Law, Pharmacy, Architecture, Dental Sciences, and Humanities</strong>.
            </p>
        </div>

        <div class="accreditation-bar" style="margin-bottom: 25px;">
            <span class="accred-chip">UGC Recognized</span>
            <span class="accred-chip">AICTE Approved</span>
            <span class="accred-chip">NAAC Accredited</span>
            <span class="accred-chip">BCI / PCI Approved</span>
        </div>

        <a href="index.jsp" class="footer-link">← Back to Homepage</a>
    </div>

    <footer>
        © <%= java.time.Year.now() %> Babu Banarasi Das University, Lucknow. All Rights Reserved.
    </footer>
</body>
</html>