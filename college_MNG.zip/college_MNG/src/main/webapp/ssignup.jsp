<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Student Registration - BBDU Lucknow</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url('bbd_student.png');">
    <div class="glass-container">
        <div class="bbd-badge">
            🎓 Student Registration
        </div>
        <h1>Student Sign Up</h1>
        <h2>Babu Banarasi Das University</h2>
        
        <% if (request.getAttribute("error") != null) { %>
            <div class="alert alert-error">⚠️ <%= request.getAttribute("error") %></div>
        <% } %>
        <% if (request.getAttribute("msg") != null) { %>
            <div class="alert alert-success">✅ <%= request.getAttribute("msg") %></div>
        <% } %>
        
        <form action="signup1" method="post">
            <div class="form-group">
                <label for="name">Student Full Name</label>
                <input type="text" id="name" name="c" required placeholder="Enter Full Name"/>
            </div>
            
            <div class="form-group">
                <label for="userid">Roll No / Student ID</label>
                <input type="text" id="userid" name="a" required placeholder="Choose Roll No or User ID"/>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="b" required placeholder="Choose a secure password"/>
            </div>
            
            <div class="btn-group">
                <input type="submit" class="btn btn-primary" value="Create Account">
                <input type="reset" class="btn btn-secondary" value="Cancel">
            </div>
        </form>
        
        <a href="student.jsp" class="footer-link">Already registered? Log In</a>
    </div>

    <footer>
        © <%= java.time.Year.now() %> Babu Banarasi Das University, Lucknow. All Rights Reserved.
    </footer>
</body>
</html>