<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Babu Banarasi Das University, Lucknow - Official Portal</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url('bbd_campus.png');">
    <div class="glass-container" style="max-width: 600px;">
        <div class="bbd-badge">
            🏛️ BBD Educational Group
        </div>
        <h1>Babu Banarasi Das University</h1>
        <h2>Lucknow, Uttar Pradesh • Administration & Academic Portal</h2>
        
        <nav class="navbar">
            <a href="home.jsp" class="nav-link">Home</a>
            <a href="login.jsp" class="nav-link">Portals</a>
            <a href="about.jsp" class="nav-link">About BBDU</a>
            <a href="contact.jsp" class="nav-link">Contact</a>
        </nav>

        <div style="margin: 25px 0; text-align: left; color: var(--text-muted); line-height: 1.6; font-size: 0.95rem; background: rgba(255, 255, 255, 0.6); padding: 18px; border-radius: 12px; border-left: 4px solid var(--bbd-gold);">
            <strong style="color: var(--bbd-navy); display: block; margin-bottom: 5px; font-size: 1.05rem;">Welcome to BBDU Portal</strong>
            Access student registration, faculty grading tools, department schedules, and executive administration services online.
        </div>

        <div class="portal-options">
            <a href="login.jsp" class="portal-btn">Access Academic Portals</a>
        </div>

        <div class="accreditation-bar">
            <span class="accred-chip">UGC RECOGNIZED</span>
            <span class="accred-chip">AICTE APPROVED</span>
            <span class="accred-chip">NAAC ACCREDITED</span>
            <span class="accred-chip">BCI / PCI APPROVED</span>
        </div>
    </div>

    <footer>
        © <%= java.time.Year.now() %> Babu Banarasi Das University, Lucknow (BBDU). All Rights Reserved.
    </footer>
</body>
</html>