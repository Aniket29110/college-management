<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>BBDU - Portal Selection</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url('bbd_campus.png');">
    <%@include file ="details.jsp"%>
    <footer>
        © <%= java.time.Year.now() %> Babu Banarasi Das University, Lucknow. All Rights Reserved.
    </footer>
</body>
</html>