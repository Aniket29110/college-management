<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Contact Us - Babu Banarasi Das University, Lucknow</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url('bbd_campus.png');">
    <div class="glass-container" style="max-width: 620px;">
        <div class="bbd-badge">
            📞 Official Contact
        </div>
        <h1>Contact BBDU Lucknow</h1>
        <h2>Get in touch with university administration</h2>
        
        <div style="margin: 22px 0; text-align: left; color: var(--text-dark); line-height: 2; font-size: 0.96rem; background: rgba(255, 255, 255, 0.7); padding: 20px; border-radius: 12px; border: 1px solid var(--glass-border);">
            <p><strong>📍 Address:</strong> BBD City, Faizabad Road, Lucknow, Uttar Pradesh - 226028</p>
            <p><strong>📞 Admission Helpline:</strong> +91 (522) 6196222 / 6196223</p>
            <p><strong>✉️ General Email:</strong> info@bbdu.ac.in</p>
            <p><strong>✉️ Admissions:</strong> admissions@bbdu.ac.in</p>
            <p><strong>🕒 Office Hours:</strong> Monday - Saturday, 9:00 AM - 5:00 PM</p>
        </div>

        <a href="index.jsp" class="footer-link">← Back to Homepage</a>
    </div>

    <footer>
        © <%= java.time.Year.now() %> Babu Banarasi Das University, Lucknow. All Rights Reserved.
    </footer>
</body>
</html>