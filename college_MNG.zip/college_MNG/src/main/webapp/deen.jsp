<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin & Dean Login - BBDU Lucknow</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url('bbd_admin.png');">
    <div class="glass-container">
        <div class="bbd-badge">
            🏛️ Administration Portal
        </div>
        <h1>Administrator Login</h1>
        <h2>Babu Banarasi Das University</h2>
        
        <% if (request.getAttribute("error") != null) { %>
            <div class="alert alert-error">⚠️ <%= request.getAttribute("error") %></div>
        <% } %>
        <% if (request.getAttribute("msg") != null) { %>
            <div class="alert alert-success">✅ <%= request.getAttribute("msg") %></div>
        <% } %>
        
        <form action="dlogin" method="post">
            <div class="form-group">
                <label for="username">Administrator / Dean ID</label>
                <input type="text" id="username" name="a" required placeholder="Enter Admin ID"/>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="b" required placeholder="Enter Password"/>
            </div>
            
            <div class="btn-group">
                <input type="submit" class="btn btn-primary" value="Sign In">
                <input type="reset" class="btn btn-secondary" value="Cancel">
            </div>
        </form>
        
        <a href="dsignup.jsp" class="footer-link">New Admin Account? Register Here</a>
        <br>
        <a href="login.jsp" class="footer-link">← Back to Portal Selection</a>
    </div>

    <footer>
        © <%= java.time.Year.now() %> Babu Banarasi Das University, Lucknow. All Rights Reserved.
    </footer>
</body>
</html>