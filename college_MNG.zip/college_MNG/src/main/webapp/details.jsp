<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<div class="glass-container">
    <div class="bbd-badge">
        🏛️ BBDU Lucknow
    </div>
    <h1>Portal Selection</h1>
    <h2>Select your BBD account type</h2>
    
    <div class="portal-options">
        <a href="student.jsp" class="portal-btn">Student Portal</a>
        <a href="faculty.jsp" class="portal-btn">Faculty Portal</a>
        <a href="deen.jsp" class="portal-btn">Administrator / Dean Portal</a>
    </div>
    
    <a href="index.jsp" class="footer-link">← Return to Main Homepage</a>
</div>