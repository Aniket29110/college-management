<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Home - Babu Banarasi Das University, Lucknow</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url('bbd_campus.png');">
    <div class="glass-container" style="max-width: 650px;">
        <div class="bbd-badge">
            🏛️ BBD Educational Group
        </div>
        <h1>Welcome to BBDU</h1>
        <h2>Transforming Education, Transforming Lives • Lucknow</h2>
        
        <p style="margin: 20px 0; color: var(--text-muted); line-height: 1.7; text-align: justify; font-size: 0.95rem;">
            Babu Banarasi Das University (BBDU), Lucknow aims to provide holistic education to students, blending academic rigor with cutting-edge technology and research. Explore our specialized portals for students, faculty members, and academic administrators.
        </p>

        <div class="portal-options">
            <a href="login.jsp" class="portal-btn">Select BBD Login Portal</a>
        </div>
        
        <a href="index.jsp" class="footer-link">← Return to Homepage</a>
    </div>

    <footer>
        © <%= java.time.Year.now() %> Babu Banarasi Das University, Lucknow. All Rights Reserved.
    </footer>
</body>
</html>