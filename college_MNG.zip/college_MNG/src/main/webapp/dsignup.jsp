<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Registration - BBDU Lucknow</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url('bbd_admin.png');">
    <div class="glass-container">
        <div class="bbd-badge">
            🏛️ Executive Registration
        </div>
        <h1>Admin Sign Up</h1>
        <h2>Babu Banarasi Das University</h2>
        
        <% if (request.getAttribute("error") != null) { %>
            <div class="alert alert-error">⚠️ <%= request.getAttribute("error") %></div>
        <% } %>
        <% if (request.getAttribute("msg") != null) { %>
            <div class="alert alert-success">✅ <%= request.getAttribute("msg") %></div>
        <% } %>
        
        <form action="dsignup" method="post">
            <div class="form-group">
                <label for="name">Admin Full Name</label>
                <input type="text" id="name" name="c" required placeholder="Enter Full Name"/>
            </div>
            
            <div class="form-group">
                <label for="userid">Admin / Dean ID</label>
                <input type="text" id="userid" name="a" required placeholder="Choose Admin ID"/>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="b" required placeholder="Choose Password"/>
            </div>
            
            <div class="btn-group">
                <input type="submit" class="btn btn-primary" value="Create Account">
                <input type="reset" class="btn btn-secondary" value="Cancel">
            </div>
        </form>
        
        <a href="deen.jsp" class="footer-link">Already registered? Log In</a>
    </div>

    <footer>
        © <%= java.time.Year.now() %> Babu Banarasi Das University, Lucknow. All Rights Reserved.
    </footer>
</body>
</html>