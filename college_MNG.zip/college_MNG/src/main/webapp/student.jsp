<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Student Login - BBDU Lucknow</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url('bbd_student.png');">
    <div class="glass-container">
        <div class="bbd-badge">
            🎓 Student Portal
        </div>
        <h1>Student Login</h1>
        <h2>Babu Banarasi Das University</h2>
        
        <% if (request.getAttribute("error") != null) { %>
            <div class="alert alert-error">⚠️ <%= request.getAttribute("error") %></div>
        <% } %>
        <% if (request.getAttribute("msg") != null) { %>
            <div class="alert alert-success">✅ <%= request.getAttribute("msg") %></div>
        <% } %>
        
        <form action="slogin" method="post">
            <div class="form-group">
                <label for="username">Student Roll No. / User ID</label>
                <input type="text" id="username" name="a" required placeholder="e.g. BBDU102938"/>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="b" required placeholder="Enter your password"/>
            </div>
            
            <div class="btn-group">
                <input type="submit" class="btn btn-primary" value="Sign In">
                <input type="reset" class="btn btn-secondary" value="Cancel">
            </div>
        </form>
        
        <a href="ssignup.jsp" class="footer-link">Don't have an account? Register Here</a>
        <br>
        <a href="login.jsp" class="footer-link">← Back to Portal Selection</a>
    </div>

    <footer>
        © <%= java.time.Year.now() %> Babu Banarasi Das University, Lucknow. All Rights Reserved.
    </footer>
</body>
</html>