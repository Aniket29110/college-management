<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*, java.util.*, com.collegemanagement.util.DBConnection" %>
<%
    String user = (String) session.getAttribute("user");
    String userName = (String) session.getAttribute("userName");
    String role = (String) session.getAttribute("role");
    
    if (user == null || role == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    Connection conn = null;
    PreparedStatement ps1 = null;
    ResultSet rs1 = null;

    // Student Data
    List<Map<String, String>> studentGrades = new ArrayList<>();
    List<Map<String, String>> studentAttendance = new ArrayList<>();
    double attRateSum = 0;
    int attCourseCount = 0;

    // Faculty Data
    List<Map<String, String>> facultyCourses = new ArrayList<>();
    List<Map<String, String>> studentList = new ArrayList<>();
    List<Map<String, String>> facultyGradesView = new ArrayList<>();
    List<Map<String, String>> facultyAttendanceView = new ArrayList<>();

    // Admin Data
    List<Map<String, String>> allCourses = new ArrayList<>();
    List<Map<String, String>> facultyList = new ArrayList<>();
    List<Map<String, String>> feedbackList = new ArrayList<>();

    try {
        conn = DBConnection.getConnection();

        if ("Student".equalsIgnoreCase(role)) {
            // Fetch Grades
            ps1 = conn.prepareStatement(
                "SELECT g.course_code, c.course_name, c.credits, g.marks, g.grade " +
                "FROM grades g JOIN courses c ON g.course_code = c.course_code " +
                "WHERE g.student_id = ?"
            );
            ps1.setString(1, user);
            rs1 = ps1.executeQuery();
            while(rs1.next()) {
                Map<String, String> m = new HashMap<>();
                m.put("code", rs1.getString("course_code"));
                m.put("name", rs1.getString("course_name"));
                m.put("credits", String.valueOf(rs1.getInt("credits")));
                m.put("marks", String.valueOf(rs1.getInt("marks")));
                m.put("grade", rs1.getString("grade"));
                studentGrades.add(m);
            }
            rs1.close();
            ps1.close();

            // Fetch Attendance
            ps1 = conn.prepareStatement(
                "SELECT a.course_code, c.course_name, " +
                "COUNT(CASE WHEN a.status = 'Present' THEN 1 END) AS attended, " +
                "COUNT(*) AS total " +
                "FROM attendance a JOIN courses c ON a.course_code = c.course_code " +
                "WHERE a.student_id = ? " +
                "GROUP BY a.course_code, c.course_name"
            );
            ps1.setString(1, user);
            rs1 = ps1.executeQuery();
            while(rs1.next()) {
                Map<String, String> m = new HashMap<>();
                int att = rs1.getInt("attended");
                int tot = rs1.getInt("total");
                double pct = tot > 0 ? ((double)att / tot) * 100 : 100.0;
                m.put("code", rs1.getString("course_code"));
                m.put("name", rs1.getString("course_name"));
                m.put("attended", String.valueOf(att));
                m.put("total", String.valueOf(tot));
                m.put("rate", String.format("%.1f", pct));
                studentAttendance.add(m);
                attRateSum += pct;
                attCourseCount++;
            }
            rs1.close();
            ps1.close();

        } else if ("Faculty".equalsIgnoreCase(role)) {
            // Fetch Faculty Courses
            ps1 = conn.prepareStatement("SELECT * FROM courses WHERE faculty_id = ?");
            ps1.setString(1, user);
            rs1 = ps1.executeQuery();
            while(rs1.next()) {
                Map<String, String> m = new HashMap<>();
                m.put("code", rs1.getString("course_code"));
                m.put("name", rs1.getString("course_name"));
                facultyCourses.add(m);
            }
            rs1.close();
            ps1.close();

            // Fetch Students
            ps1 = conn.prepareStatement("SELECT name, uid FROM studentsignup");
            rs1 = ps1.executeQuery();
            while(rs1.next()) {
                Map<String, String> m = new HashMap<>();
                m.put("name", rs1.getString("name"));
                m.put("uid", rs1.getString("uid"));
                studentList.add(m);
            }
            rs1.close();
            ps1.close();

            // Fetch current grades
            ps1 = conn.prepareStatement(
                "SELECT g.student_id, s.name AS student_name, g.course_code, g.marks, g.grade " +
                "FROM grades g JOIN studentsignup s ON g.student_id = s.uid"
            );
            rs1 = ps1.executeQuery();
            while(rs1.next()) {
                Map<String, String> m = new HashMap<>();
                m.put("student_id", rs1.getString("student_id"));
                m.put("student_name", rs1.getString("student_name"));
                m.put("code", rs1.getString("course_code"));
                m.put("marks", String.valueOf(rs1.getInt("marks")));
                m.put("grade", rs1.getString("grade"));
                facultyGradesView.add(m);
            }
            rs1.close();
            ps1.close();

            // Fetch current attendance
            ps1 = conn.prepareStatement(
                "SELECT a.student_id, s.name AS student_name, a.course_code, a.date, a.status " +
                "FROM attendance a JOIN studentsignup s ON a.student_id = s.uid ORDER BY a.date DESC"
            );
            rs1 = ps1.executeQuery();
            while(rs1.next()) {
                Map<String, String> m = new HashMap<>();
                m.put("student_id", rs1.getString("student_id"));
                m.put("student_name", rs1.getString("student_name"));
                m.put("code", rs1.getString("course_code"));
                m.put("date", String.valueOf(rs1.getDate("date")));
                m.put("status", rs1.getString("status"));
                facultyAttendanceView.add(m);
            }
            rs1.close();
            ps1.close();

        } else if ("Administrator".equalsIgnoreCase(role)) {
            // Fetch Faculty List
            ps1 = conn.prepareStatement("SELECT name, uid FROM facultysignup");
            rs1 = ps1.executeQuery();
            while(rs1.next()) {
                Map<String, String> m = new HashMap<>();
                m.put("name", rs1.getString("name"));
                m.put("uid", rs1.getString("uid"));
                facultyList.add(m);
            }
            rs1.close();
            ps1.close();

            // Fetch Student List
            ps1 = conn.prepareStatement("SELECT name, uid FROM studentsignup");
            rs1 = ps1.executeQuery();
            while(rs1.next()) {
                Map<String, String> m = new HashMap<>();
                m.put("name", rs1.getString("name"));
                m.put("uid", rs1.getString("uid"));
                studentList.add(m);
            }
            rs1.close();
            ps1.close();

            // Fetch Courses with Faculty Name
            ps1 = conn.prepareStatement(
                "SELECT c.course_code, c.course_name, c.credits, f.name AS faculty_name " +
                "FROM courses c LEFT JOIN facultysignup f ON c.faculty_id = f.uid"
            );
            rs1 = ps1.executeQuery();
            while(rs1.next()) {
                Map<String, String> m = new HashMap<>();
                m.put("code", rs1.getString("course_code"));
                m.put("name", rs1.getString("course_name"));
                m.put("credits", String.valueOf(rs1.getInt("credits")));
                m.put("faculty", rs1.getString("faculty_name") != null ? rs1.getString("faculty_name") : "Unassigned");
                allCourses.add(m);
            }
            rs1.close();
            ps1.close();

            // Fetch Feedbacks
            ps1 = conn.prepareStatement(
                "SELECT f.id, f.student_id, s.name AS student_name, f.message, f.submitted_at " +
                "FROM feedback f LEFT JOIN studentsignup s ON f.student_id = s.uid ORDER BY f.submitted_at DESC"
            );
            rs1 = ps1.executeQuery();
            while(rs1.next()) {
                Map<String, String> m = new HashMap<>();
                m.put("id", String.valueOf(rs1.getInt("id")));
                m.put("student_id", rs1.getString("student_id"));
                m.put("student_name", rs1.getString("student_name") != null ? rs1.getString("student_name") : "Unknown");
                m.put("message", rs1.getString("message"));
                m.put("date", String.valueOf(rs1.getTimestamp("submitted_at")));
                feedbackList.add(m);
            }
            rs1.close();
            ps1.close();
        }

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        try { if(rs1 != null) rs1.close(); } catch(Exception ex) {}
        try { if(ps1 != null) ps1.close(); } catch(Exception ex) {}
        try { if(conn != null) conn.close(); } catch(Exception ex) {}
    }

    double cumulativeAttendance = attCourseCount > 0 ? (attRateSum / attCourseCount) : 100.0;
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title><%= role %> Dashboard - BBDU Lucknow</title>
<link rel="stylesheet" href="style.css">
<style>
    .sub-section {
        margin-top: 35px;
        text-align: left;
        border-top: 1.5px solid rgba(11, 37, 69, 0.1);
        padding-top: 25px;
    }
    .sub-section h3 {
        color: var(--bbd-navy);
        font-size: 1.4rem;
        font-weight: 700;
        margin-bottom: 15px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 12px;
        background: rgba(255, 255, 255, 0.9);
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }
    th, td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #e2e8f0;
        font-size: 0.92rem;
    }
    th {
        background: var(--bbd-navy);
        color: var(--bbd-gold);
        font-weight: 700;
    }
    td {
        color: var(--text-dark);
    }
    tr:last-child td {
        border-bottom: none;
    }
    .badge-status {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 0.8rem;
        font-weight: 700;
        text-transform: uppercase;
    }
    .badge-present { background: #d1fae5; color: #065f46; }
    .badge-absent { background: #fee2e2; color: #991b1b; }
    
    .dashboard-actions {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 30px;
        flex-wrap: wrap;
        gap: 15px;
    }
    textarea {
        width: 100%;
        padding: 12px;
        border: 1.5px solid #cbd5e1;
        border-radius: 8px;
        font-family: inherit;
        font-size: 0.95rem;
        resize: vertical;
        min-height: 80px;
    }
    select {
        width: 100%;
        padding: 12px;
        border: 1.5px solid #cbd5e1;
        border-radius: 8px;
        font-family: inherit;
        font-size: 0.95rem;
        background: white;
    }
    .stats-card {
        background: var(--bbd-gold-light);
        border: 1.5px solid var(--bbd-gold);
        padding: 15px;
        border-radius: 10px;
        color: #92400e;
        font-weight: 700;
        margin-bottom: 20px;
    }
</style>
</head>
<body style="background-image: url('bbd_campus.png');">
    <div class="glass-container dashboard-container">
        <div class="bbd-badge">
            🏛️ BBDU Lucknow • <%= role %> Portal
        </div>
        <h1>Welcome, <%= userName %>!</h1>
        <h2>User ID: <%= user %> • Status: Verified Active</h2>

        <% if (request.getParameter("error") != null) { %>
            <div class="alert alert-error">⚠️ <%= request.getParameter("error") %></div>
        <% } %>
        <% if (request.getParameter("msg") != null) { %>
            <div class="alert alert-success">✅ <%= request.getParameter("msg") %></div>
        <% } %>

        <!-- ==================== STUDENT DASHBOARD ==================== -->
        <% if ("Student".equalsIgnoreCase(role)) { %>
            <div class="stats-card">
                📊 Cumulative Attendance: <%= String.format("%.1f", cumulativeAttendance) %>% 
                <%= cumulativeAttendance < 75.0 ? "(⚠️ Short of 75% attendance criteria)" : "(✅ Attendance criteria satisfied)" %>
            </div>

            <div class="sub-section">
                <h3>📚 Academic & Grades</h3>
                <% if(studentGrades.isEmpty()) { %>
                    <p style="color: var(--text-muted);">No graded courses available.</p>
                <% } else { %>
                    <table>
                        <thead>
                            <tr>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Credits</th>
                                <th>Marks Obtained</th>
                                <th>Letter Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% for(Map<String, String> g : studentGrades) { %>
                                <tr>
                                    <td><%= g.get("code") %></td>
                                    <td><%= g.get("name") %></td>
                                    <td><%= g.get("credits") %></td>
                                    <td><%= g.get("marks") %>/100</td>
                                    <td><strong><%= g.get("grade") %></strong></td>
                                </tr>
                            <% } %>
                        </tbody>
                    </table>
                <% } %>
            </div>

            <div class="sub-section">
                <h3>📅 Attendance Tracker</h3>
                <% if(studentAttendance.isEmpty()) { %>
                    <p style="color: var(--text-muted);">No attendance records found.</p>
                <% } else { %>
                    <table>
                        <thead>
                            <tr>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Attended Classes</th>
                                <th>Total Classes</th>
                                <th>Attendance %</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% for(Map<String, String> att : studentAttendance) { %>
                                <tr>
                                    <td><%= att.get("code") %></td>
                                    <td><%= att.get("name") %></td>
                                    <td><%= att.get("attended") %></td>
                                    <td><%= att.get("total") %></td>
                                    <td><strong><%= att.get("rate") %>%</strong></td>
                                </tr>
                            <% } %>
                        </tbody>
                    </table>
                <% } %>
            </div>

            <div class="sub-section">
                <h3>💬 Submit Feedback to Dean</h3>
                <form action="submit-feedback" method="post">
                    <div class="form-group">
                        <label for="feedbackMessage">Your Message</label>
                        <textarea id="feedbackMessage" name="message" required placeholder="Type your concerns, queries or feedback here..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: auto; padding: 10px 24px;">Submit Feedback</button>
                </form>
            </div>
        <% } %>

        <!-- ==================== FACULTY DASHBOARD ==================== -->
        <% if ("Faculty".equalsIgnoreCase(role)) { %>
            <div class="sub-section">
                <h3>📝 Mark Student Attendance</h3>
                <form action="manage-attendance" method="post">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label for="attCourse">Select Course</label>
                            <select id="attCourse" name="course_code" required>
                                <% for(Map<String, String> c : facultyCourses) { %>
                                    <option value="<%= c.get("code") %>"><%= c.get("code") %> - <%= c.get("name") %></option>
                                <% } %>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="attStudent">Select Student</label>
                            <select id="attStudent" name="student_id" required>
                                <% for(Map<String, String> s : studentList) { %>
                                    <option value="<%= s.get("uid") %>"><%= s.get("name") %> (<%= s.get("uid") %>)</option>
                                <% } %>
                            </select>
                        </div>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label for="attDate">Date</label>
                            <input type="text" id="attDate" name="date" required placeholder="YYYY-MM-DD" value="<%= java.time.LocalDate.now() %>"/>
                        </div>
                        <div class="form-group">
                            <label for="attStatus">Status</label>
                            <select id="attStatus" name="status" required>
                                <option value="Present">Present</option>
                                <option value="Absent">Absent</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: auto; padding: 10px 24px;">Submit Attendance</button>
                </form>
            </div>

            <div class="sub-section">
                <h3>🏆 Assign & Update Grades</h3>
                <form action="manage-grades" method="post">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label for="gradeCourse">Select Course</label>
                            <select id="gradeCourse" name="course_code" required>
                                <% for(Map<String, String> c : facultyCourses) { %>
                                    <option value="<%= c.get("code") %>"><%= c.get("code") %> - <%= c.get("name") %></option>
                                <% } %>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="gradeStudent">Select Student</label>
                            <select id="gradeStudent" name="student_id" required>
                                <% for(Map<String, String> s : studentList) { %>
                                    <option value="<%= s.get("uid") %>"><%= s.get("name") %> (<%= s.get("uid") %>)</option>
                                <% } %>
                            </select>
                        </div>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label for="gradeMarks">Marks Obtained</label>
                            <input type="text" id="gradeMarks" name="marks" required placeholder="e.g. 85"/>
                        </div>
                        <div class="form-group">
                            <label for="gradeLetter">Letter Grade</label>
                            <select id="gradeLetter" name="grade" required>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="F">F</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: auto; padding: 10px 24px;">Submit Grade</button>
                </form>
            </div>

            <div class="sub-section">
                <h3>📋 Existing Grades Registry</h3>
                <% if(facultyGradesView.isEmpty()) { %>
                    <p style="color: var(--text-muted);">No grade logs recorded yet.</p>
                <% } else { %>
                    <table>
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Student Name</th>
                                <th>Course</th>
                                <th>Marks</th>
                                <th>Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% for(Map<String, String> g : facultyGradesView) { %>
                                <tr>
                                    <td><%= g.get("student_id") %></td>
                                    <td><%= g.get("student_name") %></td>
                                    <td><%= g.get("code") %></td>
                                    <td><%= g.get("marks") %>/100</td>
                                    <td><strong><%= g.get("grade") %></strong></td>
                                </tr>
                            <% } %>
                        </tbody>
                    </table>
                <% } %>
            </div>

            <div class="sub-section">
                <h3>📅 Recent Attendance Records</h3>
                <% if(facultyAttendanceView.isEmpty()) { %>
                    <p style="color: var(--text-muted);">No attendance entries recorded yet.</p>
                <% } else { %>
                    <table>
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Student Name</th>
                                <th>Course</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% for(Map<String, String> a : facultyAttendanceView) { %>
                                <tr>
                                    <td><%= a.get("student_id") %></td>
                                    <td><%= a.get("student_name") %></td>
                                    <td><%= a.get("code") %></td>
                                    <td><%= a.get("date") %></td>
                                    <td>
                                        <span class="badge-status <%= "Present".equalsIgnoreCase(a.get("status")) ? "badge-present" : "badge-absent" %>">
                                            <%= a.get("status") %>
                                        </span>
                                    </td>
                                </tr>
                            <% } %>
                        </tbody>
                    </table>
                <% } %>
            </div>
        <% } %>

        <!-- ==================== ADMINISTRATOR DASHBOARD ==================== -->
        <% if ("Administrator".equalsIgnoreCase(role)) { %>
            <div class="sub-section">
                <h3>🏫 Register New Course</h3>
                <form action="manage-courses" method="post">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label for="courseCode">Course Code</label>
                            <input type="text" id="courseCode" name="course_code" required placeholder="e.g. CS101"/>
                        </div>
                        <div class="form-group">
                            <label for="courseName">Course Name</label>
                            <input type="text" id="courseName" name="course_name" required placeholder="e.g. Intro to Databases"/>
                        </div>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label for="courseCredits">Credits</label>
                            <input type="text" id="courseCredits" name="credits" required placeholder="e.g. 4"/>
                        </div>
                        <div class="form-group">
                            <label for="courseFaculty">Assign Faculty</label>
                            <select id="courseFaculty" name="faculty_id" required>
                                <% for(Map<String, String> f : facultyList) { %>
                                    <option value="<%= f.get("uid") %>"><%= f.get("name") %> (<%= f.get("uid") %>)</option>
                                <% } %>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: auto; padding: 10px 24px;">Create Course</button>
                </form>
            </div>

            <div class="sub-section">
                <h3>👤 Add User Account</h3>
                <form action="manage-users" method="post">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label for="regRole">Role</label>
                            <select id="regRole" name="role" required>
                                <option value="Student">Student</option>
                                <option value="Faculty">Faculty</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="regName">Full Name</label>
                            <input type="text" id="regName" name="name" required placeholder="e.g. John Doe"/>
                        </div>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label for="regUid">User ID / Roll No</label>
                            <input type="text" id="regUid" name="uid" required placeholder="e.g. BBDU9876"/>
                        </div>
                        <div class="form-group">
                            <label for="regPass">Password</label>
                            <input type="password" id="regPass" name="password" required placeholder="Enter login password"/>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: auto; padding: 10px 24px;">Add User Account</button>
                </form>
            </div>

            <div class="sub-section">
                <h3>📚 Registered Courses Directory</h3>
                <% if(allCourses.isEmpty()) { %>
                    <p style="color: var(--text-muted);">No courses listed.</p>
                <% } else { %>
                    <table>
                        <thead>
                            <tr>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Credits</th>
                                <th>Assigned Faculty</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% for(Map<String, String> c : allCourses) { %>
                                <tr>
                                    <td><%= c.get("code") %></td>
                                    <td><%= c.get("name") %></td>
                                    <td><%= c.get("credits") %></td>
                                    <td><%= c.get("faculty") %></td>
                                </tr>
                            <% } %>
                        </tbody>
                    </table>
                <% } %>
            </div>

            <div class="sub-section">
                <h3>💬 Student Feedbacks Inbox</h3>
                <% if(feedbackList.isEmpty()) { %>
                    <p style="color: var(--text-muted);">No feedback records submitted yet.</p>
                <% } else { %>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Student ID</th>
                                <th>Student Name</th>
                                <th>Message</th>
                                <th>Date Submitted</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% for(Map<String, String> fb : feedbackList) { %>
                                <tr>
                                    <td><%= fb.get("id") %></td>
                                    <td><%= fb.get("student_id") %></td>
                                    <td><%= fb.get("student_name") %></td>
                                    <td style="max-width: 300px; word-wrap: break-word;"><%= fb.get("message") %></td>
                                    <td><%= fb.get("date") %></td>
                                </tr>
                            <% } %>
                        </tbody>
                    </table>
                <% } %>
            </div>
        <% } %>

        <div class="dashboard-actions">
            <a href="logout" class="btn btn-primary" style="display: inline-flex; width: auto; padding: 12px 32px; text-decoration: none;">Sign Out of BBD Portal</a>
        </div>
    </div>

    <footer>
        © 2026 Babu Banarasi Das University, Lucknow. All Rights Reserved.
    </footer>
</body>
</html>
